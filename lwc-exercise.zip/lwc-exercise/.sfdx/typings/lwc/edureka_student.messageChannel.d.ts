declare module "@salesforce/messageChannel/edureka_student__c" {
    var edureka_student: string;
    export default edureka_student;
}